/**
 * Exposing intl-tel-input as a component
 */
module.exports = require("./build/js/intlTelInput");

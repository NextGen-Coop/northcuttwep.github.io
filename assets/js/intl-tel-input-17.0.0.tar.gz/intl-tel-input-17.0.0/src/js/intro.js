// wrap in UMD
(function(factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else window.intlTelInput = factory();
}(function(undefined) {
  "use strict";

  return (function() {
